<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 随机文本插件
 * 
 * 这是一个简单的随机文本显示插件，每次刷新页面时，会从配置中设置的文本列表中随机显示一段文本，
 * 并且允许用户通过设置界面自定义文本的样式（颜色、字体大小、字体类型等）。
 * 
 * @package RandomText
 * @author FRIS
 * @version 2.0.0
 * @link https://seefris.com/
 */
class RandomText_Plugin implements Typecho_Plugin_Interface
{
    // 激活插件
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->footer = array('RandomText_Plugin', 'render');
        return _t('插件已激活');
    }

    // 禁用插件
    public static function deactivate()
    {
        return _t('插件已禁用');
    }

    // 插件配置界面
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // 随机文本设置
        $texts = new Typecho_Widget_Helper_Form_Element_Textarea(
            'texts', 
            null, 
            "这是一段随机显示的文本之一。\n这是另一段随机显示的文本。",
            _t('随机文本'),
            _t('在每行输入一段随机文本，每次刷新页面将会随机显示其中之一。')
        );
        $form->addInput($texts);

        // 颜色设置
        $color = new Typecho_Widget_Helper_Form_Element_Text(
            'color', 
            null, 
            '#000000', 
            _t('字体颜色'), 
            _t('请输入颜色值（如 #000000）。')
        );
        $form->addInput($color);

        // 字体大小设置
        $fontSize = new Typecho_Widget_Helper_Form_Element_Text(
            'fontSize', 
            null, 
            '16px', 
            _t('字体大小'), 
            _t('请输入字体大小（如 16px）。')
        );
        $form->addInput($fontSize);

        // 字体设置
        $fontFamily = new Typecho_Widget_Helper_Form_Element_Text(
            'fontFamily', 
            null, 
            'Arial, sans-serif', 
            _t('字体'), 
            _t('请输入字体名称（如 Arial, sans-serif）。')
        );
        $form->addInput($fontFamily);
    }

    // 个人用户的配置界面
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    // 输出随机文本
    public static function render()
    {
        // 获取插件配置
        $options = Helper::options()->plugin('RandomText');
        
        // 获取配置的随机文本
        $texts = explode("\n", $options->texts);
        $randomText = $texts[array_rand($texts)];

        // 获取配置的样式
        $color = isset($options->color) ? $options->color : '#000000'; // 默认黑色
        $fontSize = isset($options->fontSize) ? $options->fontSize : '16px'; // 默认字体大小16px
        $fontFamily = isset($options->fontFamily) ? $options->fontFamily : 'Arial, sans-serif'; // 默认字体

        // 输出带有自定义样式的随机文本
        echo '<div class="random-text" style="color: ' . htmlspecialchars($color) . '; font-size: ' . htmlspecialchars($fontSize) . '; font-family: ' . htmlspecialchars($fontFamily) . ';">' . htmlspecialchars($randomText) . '</div>';
    }
}
